<?php $__env->startSection('pageTitle','لوحة التحكم '); ?>

<?php $__env->startSection('pageSubTitle', 'تعديل مستخدم'); ?>



    <!-- start header
     ================ -->
<?php $__env->startSection('content'); ?>
            <!--start row-->
            <div class="row">
                <!--start div-->
                <div class="breadcrumbes col-12">
                    <ul class="list-inline">
                        <li><a href="#"><i class="fa fa-home"></i>الرئيسية</a></li>
                        <li>المستخدمين</li>
                    </ul>
                </div>
                <!--end div-->


                <!--start div-->
                <div class="col-md-12 clients-grid margin-bottom-div">
                    <div class="main-white-box">
                        <h3 class="sec-title color-title"><span>تعديل المستخدم </span></h3>
                     

                        <form  method="post" action='<?php echo e(route('users.update',$user->id)); ?>' class="needs-validation row border-form"  enctype="multipart/form-data" novalidate="">
            <?php echo csrf_field(); ?>
<?php echo method_field('put'); ?>
                            <div class="form-group  col-md-6">
                                <label>الإسم بالكامل<span class="starrisk">*</span></label>
                                <input type="text" class="form-control" value="<?php echo e($user->name); ?>"   name="name"placeholder="الإسم  " required>
                                <div class="invalid-feedback">
                                    من فضلك أدخل اسم صحيح
                                </div>
                                <?php if($errors->has('name')): ?>
                                   <div style="display:block;" class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group  col-md-6">
                                <label>البريد الإلكتروني<span class="starrisk">*</span></label>
                                <input type="email" class="form-control"  value="<?php echo e($user->email); ?>"name="email" placeholder="البريد الإلكتروني" required>


                                <div class="invalid-feedback">
                                    من فضلك أدخل بريد إلكتروني صحيح
                                </div>

                                <?php if($errors->has('email')): ?>
                                    <div style="display:block;" class="invalid-feedback"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>

                            <div class="form-group  col-md-6">
                                <label>رقم الجوال<span class="starrisk">*</span></label>
                                <input type="tel" class="form-control" value="<?php echo e($user->phone); ?>" name="phone" id="phone" minlength="10"
                                       maxlength="14" required>
                                <div class="invalid-feedback">
                                    من فضلك أدخل جوال صحيح
                                </div>
                            </div>
                            <?php if($errors->has('phone')): ?>
                                <div style="display:block;" class="invalid-feedback"><?php echo e($errors->first('phone')); ?></div>
                            <?php endif; ?>




                           

                            <div class="form-group  col-md-6">
                                <label>المدينه <span class="starrisk">*</span></label>
                                <select class="form-control"  id="citysel" name="city_id" required>
                                    <option value="<?php echo e(isset($city)?$city->name:"لا يوجد"); ?>" selected disabled>
                                        <?php echo e(isset($city)?$city->name:'لا يوجد '); ?>

                                    </option>
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($key); ?>" ><?php echo e($value); ?> </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <div class="invalid-feedback">
                                    من فضلك إختر مدينه صحيحة
                                </div>




                            </div>
                            <div class="form-group col-md-6">
                                <label class="control-label">الوظيفه</label>
                                <input type="text"    readonly value="<?php echo e($roles[$user->type]); ?>"  class="form-control">
                            </div>


                            <div class="form-group col-md-6">
                                <label class="control-label">كلمة المرور الجديدة</label>
                                <input type="password" name="password" class="form-control">
                            </div>

                            <div class="form-group col-md-6">
                                <label class="control-label">تأكيد كلمة المرور</label>
                                <input type="password" name="password_confirmation" class="form-control">
                                <?php if($errors->has('password')): ?>
                                    <div class="invalid-feedback" style="display: block"><?php echo $errors->first('password'); ?></div>
                                <?php endif; ?>
                            </div>



                            <div class="form-group col-md-6 text-center">
                                <div class="custom-file-div">
                                    <input type="file"
                                           class="file-input form-control" value=""  name="image"
                                           id="imageUpload" >
                                    <label class="file-input-label" for="imageUpload"> إضافة
                                        صورة</label>


                                    <div class="img_contain">
                                        <img id="imagePreview" /></div>
                                </div>
                            </div>


                            <div class="form-group col-md-6 ">
                                <img src="<?php echo e(($user->image)?asset('storage/'.$user->image):asset('/admin/images/main/avatar.png')); ?>">
                            </div>

                           

                            <div class="form-group  margin-top-div text-center col-12">
                                <button type="submit" class="more-link color-bg inline-block-btn">حفظ</button>
                                <?php if($user->is_active==1): ?>
                                <a href="<?php echo e(route('status',[$user->id,0])); ?>" class="more-link color-bg inline-block-btn remove-btn ">حظر</a>
                                    <?php else: ?>
                                    <a href="<?php echo e(route('status',[$user->id,1])); ?>" class="remove-btn">تفعيل</a>
                                    <?php endif; ?>
                            </div>



                        </form>
                    </div>

                </div>
                <!--end div-->

            </div>
            <!--end row-->

<?php $__env->stopSection(); ?>

                <?php $__env->startSection('script'); ?>
                    <script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"></script>
                    <script src="<?php echo e(asset('js/additional-methods.min.js')); ?>"></script>
                    <script src="<?php echo e(asset('js/messages_ar.min.js')); ?>"></script>
                    <script>
                        $( "#myform" ).validate();
                    </script>

                    <script>
                     /*   function readURL(input) {
                            if (input.files && input.files[0]) {
                                var reader = new FileReader();

                                reader.onload = function (e) {
                                    imgId = '#preview-' + $(input).attr('id');
                                    $(imgId).attr('src', e.target.result);
                                }

                                reader.readAsDataURL(input.files[0]);
                            }

                        }
                        $(".style-file-input").on("change", function () {
                            var fileName = $(this).val().split("\\").pop();
                            $(this).siblings(".style-file-label").addClass("selected").html(fileName);
                            readURL(this);

                        });
*/

                        function readURL(input) {
                            if (input.files && input.files[0]) {
                                var reader = new FileReader();
                                reader.onload = function(e) {
                                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                                    $('#imagePreview').hide();
                                    $('#imagePreview').fadeIn(650);
                                }
                                reader.readAsDataURL(input.files[0]);
                            }
                        }
                        $("#imageUpload").change(function() {
                            readURL(this);
                            $(this).next("label").css({"background":"transparent"}).text("");
                        });



                    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript" src="<?php echo e(asset('admin/js/main.js')); ?>"></script>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/members/edit.blade.php ENDPATH**/ ?>
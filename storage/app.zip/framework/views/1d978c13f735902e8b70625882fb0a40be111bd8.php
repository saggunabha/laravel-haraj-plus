



<?php $__env->startSection('pageTitle'); ?>لوحة التحكم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSubTitle'); ?>  رسائل الدعم الفني
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--start row-->
    <div class="row">
        <!--start div-->
        <div class="breadcrumbes col-12">
            <ul class="list-inline">
                <li><a href="<?php echo e(route('main')); ?>"><i class="fa fa-home"></i>الرئيسية</a></li>
                <li> رسائل الدعم الفني</li>
            </ul>
        </div>
        <!--end div-->


        <!--start div-->
        <div class="col-md-12 clients-grid margin-bottom-div">
            <table id="example" class="table table-striped table-bordered dt-responsive nowrap"
                   style="width:100%">
                <thead>
                <tr>
                    <th>#</th>
                    <th>التاريخ</th>
                    <th>الاسم</th>
                    <th>الايميل</th>
                    <th>عنوان الطلب</th>
                    <th>نص الطلب</th>
                    <th>تعديل</th>

                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $techs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e(date('j M Y, h:i A', strtotime($subscriber->created_at))); ?></td>
                        <td><?php echo e($subscriber->name); ?></td>
                        <td><?php echo e($subscriber->email); ?></td>
                        <td><?php echo e($subscriber->subject); ?></td>
                        <td><?php echo e($subscriber->message); ?></td>
                        <td>
                        <a title="delete" onclick="return true;" object_id="<?php echo e($subscriber->id); ?>" delete_url="/techs/" class="edit-btn-table remove-alert" href="#">
                                <i class="fa fa-times"></i> </a>
                        <a class="watch" href="#" onclick="return true;" data-url="<?php echo e(route('tech-replay',$subscriber->id)); ?>"  data-subject="<?php echo e($subscriber->subject); ?>"
                            data-message="<?php echo e($subscriber->message); ?>" data-all="<?php echo e($subscriber->replay); ?>" data-recipient="<?php echo e($subscriber->user_id); ?>"  data-toggle="modal" data-target="#order-modal">
                            <i class="fas fa-reply"></i>
                        </a>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

        </div>
        <!--end div-->

    </div>
    <!--end row-->

    <div class="modal o-modal fade" id="order-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <a type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </a>
                </div>
                <div class="modal-body" id="popup">
                    <h3>عنوان الطلب</h3>
                    <p id="show-subject"> </p>
                    <h3>الطلب</h3>
                    <p id="show-message"> </p>
                    <br/>
                    <br/>
                   <p>
                       رد الدعم 
                   </p>
              <div class="techs"></div>
                   
                    <form action="" >
                        <input type="text" name="message" id="tech-message" required>
                        <input type="hidden" name="user_id" value="" id="show_user_id">
                        <input type="hidden" id="action-url" value="">
                        <input type="submit" value="رد" id="submit-replay" >
                    </form>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
 $('#order-modal').on('show.bs.modal', function (event) {
    $(this).find(".techs").empty();
    var element = $(event.relatedTarget); 
    var recipient = element.data('recipient'); 
    var message = element.data('message');
    var subject = element.data('subject');
    var action = element.data('url');
    
    var modal = $(this);
    $('#show-subject').text(subject);
    $('#show-message').text(message);
    $('#show_user_id').val(recipient);
    $('#action-url').val(action);
    if(element.data('all').length !=0){
    var replies = element.data('all');
    
    $(this).find(".techs").append('</p>'+replies['message']+'</p>')
    // for(var x= 0;x<replies.length;x++){
    // $(this).find(".techs").append('</p>'+replies[x]['message']+'</p>');
    // }
};
$('#submit-replay').click(function(event){
	event.preventDefault();
    var replay = $('#tech-message').val();
    var token=$('meta[name="csrf-token"]').attr('content');

    $.ajax({
    url : action,
    type:'POST',
    dataType: "json",
    data:{"user_id":recipient , "message":replay,"_token":token},
    success: function(response) {
        if(response['success']){
               Swal.fire({
                        type: 'success',
                        title: 'تم إرسال الرسالة بنجاح',
                        showConfirmButton: false,
                        timer: 1500
                    })
                    location.reload();
                    $('#subject').val('');
                    $('#message').val('');
                    $('#order-modal').modal('toggle');
        }else{
            Swal.fire({
                        type: 'error',
                        title: 'تم الرد مسبقا',
                        showConfirmButton: false,
                        timer: 1500
                    })
                    $('#subject').val('');
                    $('#message').val('');
        }

    }

});
});



});
</script>





<?php $__env->stopSection(); ?>





<!-- scripts
     ================ -->




<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/techs/index.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <!--start div-->
        <div class="breadcrumbes col-12">
            <ul class="list-inline">
                <li><a href="#"><i class="fa fa-home"></i>الرئيسيه</a></li>
                <li>طلبات الترقيه</li>
            </ul>
        </div>
        <!--end div-->


        <!--start div-->
        <div class="col-md-12 clients-grid margin-bottom-div">
            <?php if(Session::has('success')): ?>
                <div class="alert alert-success alert-styled-left">
                    <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <table id="example" class="table table-striped table-bordered dt-responsive nowrap"
                   style="width:100%">
                <thead>
                <tr>
                    <th>#ID</th>
                    <th>اسم المحول</th>
                    <th>رقم الحساب البنكى</th>
                    <th>صاحب الطلب</th>
                    <th>تاريخ التحويل</th>
                    <th>نوع الباقه</th>
                    <th>الحاله</th>
                    <th>الاجراء المتخذ</th>

                </tr>
                </thead>
                <tbody>
                <?php $i=1;?>

                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($i++); ?></td>
                        
                        <td><?php echo e($payment->transferee_name); ?></td>
                        <td><?php echo e($payment->bank_no); ?></td>
                        <td><?php echo e(isset($payment->user)?$payment->user->email:''); ?></td>
                        <td><?php echo e($payment->transfer_date); ?></td>
                        <?php if(isset($payment->pakage)): ?>
                        <td><?php echo e($payment->pakage->type); ?></td>
                        <?php else: ?>
                        <td>غير محدد</td>
                        <?php endif; ?>
                        <?php if($payment->is_accepted==1): ?>
                            <td>تم القبول</td>
                            <?php elseif($payment->is_accepted==0): ?>
                        <?php else: ?>
                            <td>قيد الانتظار </td>
                        <?php endif; ?>

                        <td>
                            <a href="<?php echo e(route('payments.show',$payment->id)); ?>"  class="more-link color-bg inline-block-btn m-0">  التفاصيل</a>

                           <!-- <a title="delete" onclick="return false;" object_id="<?php echo e($payment->id); ?>" delete_url="/payments/"
                               class="edit-btn-table remove-alert" href="#">
                                <i class="fa fa-times"></i> </a> -->
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                </tbody>
            </table>

        </div>
        <!--end div-->


        <!--end row-->

    </div>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/payments/index.blade.php ENDPATH**/ ?>
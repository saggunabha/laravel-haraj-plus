 <?php $__env->startSection('footer'); ?>
<footer>
    <div class="inner-footer wow fadeIn">
        <div class="top-arrow auto-icon"><i class="fas fa-chevron-up"></i></div>
        <div class="container">
            <div class="row">
                <!--start footer-logo-->
                <div class="footer-logo  col-xl-3 col-lg-6 col-md-6 col-sm-6 text-dir-center">
                    <img src="<?php echo e(asset('/storage/' . $logoFooter)); ?>" alt="logo" />

                    <p class="white-text">
                        <?php echo e($description); ?>

                    </p>


                    <!--start social-grid-->
                    <div class="social-div">
                        <ul class="list-inline footer-social auto-icon">
                            <li>
                             <?php if(isset($youtubeUrl)): ?>   <a href="<?php echo e($youtubeUrl); ?>" target="_blank" title="يوتيوب"><img src="<?php echo e(asset('website/images/social/1.png')); ?>"<?php endif; ?>
                                                                               alt="img"></a>
                            </li>
                            <?php if(isset(\App\Models\Setting::where('key','whatsapp')->first()->value)): ?>
                            <li>
                                <a href="https://wa.me/?text=<?php echo e(\App\Models\Setting::where('key','whatsapp')->first()->value); ?>" target="_blank" title="واتس اب"><img src="<?php echo e(asset('website/images/social/2.png')); ?>"
                                                                                alt="img"></a>
                            </li>
                            <?php endif; ?>

                            <?php if(isset($snapchatUrl)): ?>
                            <li>
                                <a href="<?php echo e($snapchatUrl); ?>" target="_blank" title="سناب شات"><img src="<?php echo e(asset('website/images/social/3.png')); ?>"
                                                                                 alt="img"></a>
                            </li>
                            <?php endif; ?>
                            <?php if(isset($twitterUrl)): ?>
                            <li>
                                <a href="<?php echo e($twitterUrl); ?>" target="_blank" title="تويتر"><img src="<?php echo e(asset('website/images/social/4.png')); ?>"
                                                                               alt="img"></a>
                            </li>
                            <?php endif; ?>
                            <?php if(isset($facebookUrl)): ?>
                            <li>
                                <a href="<?php echo e($facebookUrl); ?>" target="_blank" title="فيسبوك"><img src="<?php echo e(asset('website/images/social/5.png')); ?>"
                                                                               alt="img"></a>
                            </li>
                            <?php endif; ?>
                            <?php if(isset($instagramUrl)): ?>
                            <li>
                                <a href="<?php echo e($instagramUrl); ?>" target="_blank" title="انستجرام"><img src="<?php echo e(asset('website/images/social/6.png')); ?>"
                                                                                 alt="img"></a>
                            </li>
                                <?php endif; ?>

                        </ul>
                    </div>
                    <!--end social-grid-->
                </div>
                <!--end footer-logo-->

                <!--start footer-list-grid-->
                <div class="footer-list-grid col-xl-6">
                    <div class="row no-marg-row">
                        <div class="footer-list col-lg-6 col-6">
                            <h2 class="footer-title">عن الموقع</h2>
                            <ul class="list-unstyled">


                                <li><a href="<?php echo e(isset($about->url)?$about->url:route('who')); ?>" target="_blank">من نحن</a></li>
                                <li><a href="<?php echo e(route('contact')); ?>">اتصل بنا </a></li>
                                <li><a href="<?php echo e(isset($privacy->url)?$privacy->url:route('privacy')); ?>">سياسة الخصوصية</a></li>
                                <li><a href="<?php echo e(isset($conditions->url)?$conditions->url:route('terms')); ?>">الشروط والأحكام</a></li>
                                <li><a href="<?php echo e(isset($questions->url)?$questions->url:route('questions')); ?>">الأسئلة الشائعة</a></li>
                                <li><a href="<?php echo e(isset($googleplay_url)?$googleplay_url:"#"); ?>"><img src="<?php echo e(asset('website/images/android.png')); ?>"/></a></li>
                                <li><a href="<?php echo e(isset($applestore_url)?$applestore_url:"#"); ?>"><img src="<?php echo e(asset('website/images/ios.png')); ?>"/></a></li>
                             

                                


                            </ul>
                        </div>

                        <div class="footer-list col-lg-6 col-6">
                            <h2 class="footer-title">الروابط المهمة</h2>
                            <ul class="list-unstyled">

                                <li><a href="<?php echo e($blogUrl); ?>"   target="_blank">المدونة</a></li>
                                <li><a href="<?php echo e(route('prohibited')); ?>"  >السلع الممنوعة</a>
                                <li><a href="<?php echo e(route('show-tech')); ?>"  > الدعم الفنى</a></li>
                                <li><a href="<?php echo e(route('payment_porcedures')); ?>"  >اجراءات وسياسات الدفع</a></li>
                                <li><a href="<?php echo e(route('haraj-specials')); ?>"  >مميزات الحساب المدفوع</a></li>

                                <li><a <?php if(auth()->guest()): ?> data-toggle="modal" data-target="#login-modal" <?php endif; ?> href="<?php echo e(route('paymentMethods',2)); ?>">طرق الدفع</a></li>

                    <li class="footer-pay-methods">
                  <i class="fab fa-cc-visa"></i><i class="fab fa-cc-mastercard"></i><i class="fas fa-landmark"></i>
                        </li>

                            </ul>
                        </div>
                    </div>
                </div>
                <!--end footer-list-grid-->


                <div class="subscribe-grid col-xl-3 col-lg-6 col-sm-6">
                    <h2 class="footer-title"> القائمة البريدية</h2>

                    <div class="subscribe-form white-holder icons-form">
                        <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                    

                       <!-- Begin Mailchimp Signup Form -->
                <link href="//cdn-images.mailchimp.com/embedcode/classic-10_7.css" rel="stylesheet" type="text/css">
          
                <div id="mc_embed_signup">
                <form  action="https://haraj-plus.us4.list-manage.com/subscribe/post?u=71d7265ec27139af8e84dc440&amp;id=15d0d6c578" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="needs-validation" target="_blank"  novalidate>
                <div id="mc_embed_signup_scroll">
               
                <div class=" form-group">
                <i class="fa fa-user form-icon"></i>
                <input type="text" value="" name="LNAME" placeholder="الاسم"  required class="required form-control" id="mce-LNAME">
                <div class="invalid-feedback">
                    من فضلك أدخل الاسم 
                </div>
               </div>
                <div class=" form-group">
                    <i class="fa fa-envelope form-icon"></i>
                <input type="email" value="" name="EMAIL" placeholder="البريد الإلكتروني" required class="required email form-control" id="mce-EMAIL">
                <div class="invalid-feedback">
                    من فضلك أدخل البريدالالكتروني 
                </div>
               </div>
                <div id="mce-responses" class="clear">
                <div class="response" id="mce-error-response" style="display:none"></div>
                <div class="response" id="mce-success-response" style="display:none"></div>
                </div> <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                <div style="position: absolute; left: -5000px;" aria-hidden="true">
                <input type="text" name="b_71d7265ec27139af8e84dc440_15d0d6c578" tabindex="-1" value=""></div>
                <div class=" form-group">
                <button type="submit"  name="subscribe" id="mc-embedded-subscribe" class="custom-btn dark-btn big-btn full-width-btn">اشتراك</button></div>
                </div>
                </form>

                </div>
        
                <!--End mc_embed_signup-->
                    </div>
                    
                    <div class="maarof">
                        <a href="https://maroof.sa/124400">
                    <img src="<?php echo e(asset('website/images/main/maaroof.png')); ?>" alt="">
                        </a>
                    </div>

                </div>
            </div>
        </div>
        

        <div class="copyrights text-center">
            <div class="container">
                <div class="row">
                    <div class="col-12 ">
                        <a href="<?php echo e(route('home')); ?>"  title="حراج بلص">مؤسسة حراج بلص التجارية ® - السعودية (2020)</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php $__env->stopSection(); ?>
<?php /**PATH /home/harajplus/public_html/resources/views/website/layouts/footer.blade.php ENDPATH**/ ?>
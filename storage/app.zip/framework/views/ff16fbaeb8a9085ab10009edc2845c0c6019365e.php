

<header class="first_bg  wow fadeIn"><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <div class="container">
        <div class="row">
            <!--start div-->
            <div class="col-lg-5 col-md-7  sm-center main-search-grid">
                <div class="main-search">
                    <form class="needs-validation red-form" method="get" action="<?php echo e(route('search.result')); ?>" novalidate>
                        <div class="form-group">
                            <input class="form-control" name="search" placeholder="ابحث هنا" required />
                            <div class="invalid-feedback">
                                من فضلك أدخل نص صحيح
                            </div>
                            <button type="submit" class="pos-search-btn first_bg second_bg_hover auto-icon "><i
                                    class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end div-->

            <!--start div-->
            <!--before login-->
            <?php if(!auth()->id()): ?>
            <div class="col-lg-7 col-md-5 d-md-block d-none login-grid text-left-dir sm-center">
                <div class="main-login">
                    <div class="before-login">
                        <a  href="#" data-toggle="modal" data-target="#login-modal" class="second_color_hover">تسجيل
                            الدخول</a>
                        <a  href="<?php echo e(route('signUp')); ?>"
                           class="white-btn second_bg_hover"> حساب جديد</a>
                    </div>
                </div>



            </div>
            <?php else: ?>
            <!--after login-->
            <div class="col-lg-7 col-md-5  login-grid text-left-dir sm-center">
                <div class="main-login">
                    <div class="after-login">
                        <div class="after-login-div">
                            <a  href="<?php echo e(route('chat.index')); ?>" class="white-btn second_bg_hover"><i class="fas fa-comment-dots"></i>
                                <span  id="msg" class="login-btn-text">الرسائل</span>
                                
                                <span  class="login-btn-num msg" id="message_count"></span>

                            </a>

                            <div class="arrow-list big-arrow-list">
<!--                                <ul  id="list_msg" class="list-unstyled">-->
<!--                                    <?php if(isset($client_messages)&&$client_messages->isNotEmpty()): ?>-->
<!--                                    <?php $__currentLoopData = $client_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client_message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
<!--                                    <li>-->
<!--                                        <a  href="<?php echo e(route('chat.getChat',$client_message->id)); ?>">-->
<!--                                            <img src="<?php echo e(isset($client_message->getSender->image)&&file_exists('storage/'.$client_message->getSender->image)?asset('storage/'.$client_message->getSender->image):asset('website/images/avatar.png')); ?>" alt="img" />-->
<!--                                            <div class="side-login">-->
<!---->
<!---->
<!--                                                <h3>قام <?php echo e($client_message->getSender->name); ?> بإرسال رسالة لك</h3>-->

<!--                                                <span class="login-time"><i class="far fa-clock"></i><?php echo e($client_message->created_at->diffForHumans()); ?>-->
<!--                                                        </span>-->
<!--                                            </div>-->
<!--                                        </a>-->
<!--                                    </li>-->
<!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>-->
<!--                                        <?php else: ?>-->
<!--                                        <li>لا توجد رسائل</li>-->
<!--                                    <?php endif; ?>-->

<!--                                </ul>-->
                                <!--<?php if(isset($client_messages)&&$client_messages->isNotEmpty()): ?>-->

                                <!--<div class="text-center">-->
                                <!--    <a  href="<?php echo e(route('chat.index')); ?>" class="show-all">عرض الكل</a>-->
                                <!--</div>-->
                                <!--    <?php endif; ?>-->
                            </div>
                        </div>

                        <div class="after-login-div">
                            <div id="notify">
                            <a  href="#" class="white-btn second_bg_hover"><i class="fa fa-bell"></i>
                                <span class="login-btn-text">الإشعارات</span>

                                <span  id="btn-num" <?php if(auth()->user()->Notifications->count()==0): ?> style="display: none" <?php endif; ?> class="login-btn-num notify"><?php echo e(auth()->user()->Notifications->count()!=0?auth()->user()->unReadNotifications->count():''); ?></span>

                            </a>
                        </div>
                            <div class="arrow-list big-arrow-list">
                                <?php if(auth()->user()->Notifications->isNotEmpty()): ?>
                                <ul  id="list_notify"   class="list-unstyled">

                                    <?php $__currentLoopData = auth()->user()->Notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li >
                                  
                                            <a  href="<?php echo e(isset($notification->data['actionUrl'])?$notification->data['actionUrl']:''); ?>">
                                                <img src="<?php echo e(isset($notification->data['image'])?asset('storage/'.$notification->data['image']):asset('admin/images/main/avatar.png')); ?>" alt="img" />
                                                
                                                <div class="side-login">

                                                    <h3><?php echo e(isset($notification->data['message'])?$notification->data['message']:''); ?> </h3>

                                                    <span class="login-time"><i class="far fa-clock"></i> <?php echo e($notification->data['message']?$notification->created_at->diffForHumans(Carbon\Carbon::now(), false):''); ?></span>
                                                </div>
                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
<?php else: ?>
                                    <h4 class='empty-div-messages text-center'>لا يوجد اشعارات</h4>
                                <?php endif; ?>
                               

                            </div>

                        </div>


                        <div class="after-login-div">
                            <a  href="#" class="user-img full-width-img"><img  <?php if(auth()->user()->image): ?>src="<?php echo e(asset('storage/'.auth()->user()->image)); ?>" <?php else: ?> src="<?php echo e(asset('admin/images/main/avatar.png')); ?>"<?php endif; ?> class="converted-img" alt="user" />
                            </a>


                            <div class="arrow-list">
                                <!--for user-->
                                <ul class="list-unstyled">
                                    <?php if(auth()->user()->is_promoted==1): ?>
                                    <li><a  href="<?php echo e(route('business-profile',auth()->id())); ?>" ><i class="far fa-user"></i><?php echo e(auth()->user()->name .' متجري'); ?> </a>
                                     <?php endif; ?>
                                    <li><a     href="<?php echo e(route('showProfile')); ?>"  ><i class="far fa-user"></i>اعلاناتى</a>


                                    </li>


                                        <?php if(auth()->user()->type==1): ?>

                                            <li><a  href="<?php echo e(route('main')); ?>"><i class="fa fa-user"></i>لوحه التحكم </a>
                                            </li>
                                            <?php endif; ?>


                                    <li><a  href="<?php echo e(route('edit-data')); ?>"><i class="fa fa-edit"></i>تعديل البيانات</a>
                                    </li>
                                        <?php if(auth()->user()->is_promoted==0 || auth()->user()->is_promoted==2): ?>
                                    <li><a  href="<?php echo e(route('package')); ?>"><i class="far fa-sun"></i>ترقية
                                            الحساب</a>
                                    </li>
                                        <?php endif; ?>






                                            <li><a  href="<?php echo e(route('products.add')); ?>"><i class="fa fa-plus"></i>إضافة
                                                    إعلان</a>
                                            </li>

                                       
<?php if(isset($support->url)): ?>

                                    <li><a  href="<?php echo e(route('tech')); ?>"><i class="fa fa-headset"></i>الدعم الفني</a></li>
                                    <?php endif; ?>
                                    <li><a  href="<?php echo e(route('Logout')); ?>"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
                                </ul>

                              
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--end after login-->
            <?php endif; ?>
        </div>

    </div>
</header>
<?php /**PATH /home/harajplus/public_html/resources/views/website/layouts/header.blade.php ENDPATH**/ ?>
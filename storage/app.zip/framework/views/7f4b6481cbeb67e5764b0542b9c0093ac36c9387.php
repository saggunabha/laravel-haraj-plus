<?php $__env->startSection('content'); ?>

    <!-- start pay-ment-title -->
    <div class="pay-ment-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>
                        طرق الدفع
                    </h1>
                    <p>
                        اختر طريقة الدفع المناسبة لك
                    </p>
                    <p>
                       
                        <?php echo e(isset($package)?$package->type: ''); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>
    <!-- end pay-ment-title -->

    <!-- start  choose -pay-ment- -->

<?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="Choose-pay-ment container  wow fadeIn">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-3 img-pay-ment">
                <div class="img-pay-men-1">
                    <?php if($paymentMethod->type=='حساب بنكى'): ?>
                        <p> تحويل بنكى</p>
                    <?php else: ?>
                    <img src="<?php echo e(asset($paymentMethod->image)); ?>" alt="">
                        <?php endif; ?>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-6">
                <?php if($paymentMethod->type == 'حساب بنكى'): ?>
                <p>ادفع عن طريق استخدام <?php echo e($paymentMethod->type); ?> الخاص بك </p>
         <?php else: ?>
         
            <p>ادفع عن طريق استخدام <?php echo e($paymentMethod->type); ?> الخاصة بك </p>
         
         <?php endif; ?>
            </div>

            <div class="col-lg-3 col-md-3 col-3">

                 <?php if($paymentMethod->type=='حساب بنكى'): ?><a href="<?php echo e(route('payments.create',$package->type)); ?>"  class="custom-btn"> اختيار</a>
                  <?php else: ?> 
                    <form action="<?php echo e(route('pay')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                       <input type="hidden" name="type" value="<?php echo e($paymentMethod->type); ?>">
                       <input type="hidden" name="price" value="<?php echo e($package->price); ?>">
                       <input type="hidden" name="package" value="<?php echo e($package->id); ?>">
                       <input type="submit" class="custom-btn payment" value="اختيار">
                    </form>
                    <?php endif; ?> 

            </div>

        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/website/paymentMethods.blade.php ENDPATH**/ ?>
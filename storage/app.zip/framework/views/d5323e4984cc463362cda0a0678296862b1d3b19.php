<!DOCTYPE html>

<html>

<head>
    <title><?php echo $__env->yieldContent('pageTitle'); ?> | <?php echo $__env->yieldContent('pageSubTitle'); ?></title>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="dashboard website" />
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <!-- Chrome, Firefox OS and Opera -->
    <meta name="theme-color" content="#636363">
    <meta name="csrf-token" id="token" content="<?php echo e(csrf_token()); ?>" />
    <!-- Windows Phone -->
    <meta name="msapplication-navbutton-color" content="#636363">
    <!-- iOS Safari -->
    <meta name="apple-mobile-web-app-status-bar-style" content="#636363">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link rel="shortcut icon" href="<?php echo e(asset('images/main/favicon.ico')); ?>" />




    <!-- Style sheet
         ================ -->

    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/bootstrap.min.css')); ?>" type="text/css" />
    <!--arabic-style only-->
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/bootstrap-rtl.min.css')); ?>" type="text/css" />
    <!--end-->

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/animate.min.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.css"
          type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('website/css/emoji.css')); ?>" type="text/css" />

    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/general.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/header.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/footer.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/keyframes.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/style.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/admin/colors/blue.css')); ?>" type="text/css" />
    <link rel="stylesheet" href="<?php echo e(asset('/admin/css/responsive.css')); ?>" type="text/css" />
</head>

<body>

<section class="main-content">

    <?php echo $__env->make('admin.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
        <div class="col-12 main-content-grid">

            <?php echo $__env->make('admin.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>

    <?php echo $__env->make('admin.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</section>

<script type="text/javascript" src="<?php echo e(asset('/admin/js/html5shiv.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/admin/js/respond.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/admin/js/jquery-3.4.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/admin/js/popper.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/admin/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('/admin/js/html5lightbox.js')); ?>"></script>

<script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/8.11.8/sweetalert2.all.min.js"></script>
<script type="text/javascript" src="<?php echo e(asset('/admin/js/custom-sweetalert.js')); ?>"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js">
</script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js">
</script>
<script src="<?php echo e(asset('/admin/js/wow.min.js')); ?>" type="text/javascript"></script>
<script src="<?php echo e(asset('/admin/js/custom.js')); ?>" type="text/javascript"></script>

<script src="<?php echo e(asset('/admin/js/main.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(URL::asset('admin/plugins/ckeditor/ckeditor.js')); ?>"></script>
<script>
    //data-tables

        //data-tables
        $(document).ready(function () {
        $('#example').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.10.19/i18n/Arabic.json"

            },

        });

    });



</script>
<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html>
<?php /**PATH /home/harajplus/public_html/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>
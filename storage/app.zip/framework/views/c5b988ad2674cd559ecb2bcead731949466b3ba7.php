<?php if(auth()->user()->unReadNotifications->isNotEmpty()): ?>

    <?php $__currentLoopData = auth()->user()->unReadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(in_array($notification->created_at->diffInSeconds(Carbon\Carbon::now(), false),range(0,5))): ?>
        <li >
            <a  href="<?php echo e(isset($notification->data['actionUrl'])?$notification->data['actionUrl']:''); ?>">
                <img src="<?php echo e(isset($notification->data['image'])?asset('storage/'.$notification->data['image']):asset('admin/images/main/avatar.png')); ?>" alt="img" />
                

                <div class="side-login">

                    <h3><?php echo e(isset($notification->data['message'])?$notification->data['message']:''); ?> </h3>

                    <span class="login-time"><i class="far fa-clock"></i> <?php echo e($notification->data['message']?$notification->created_at->diffForHumans(Carbon\Carbon::now(), false):''); ?></span>
                </div>
            </a>
        </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php endif; ?><?php /**PATH /home/harajplus/public_html/resources/views/website/load_notification.blade.php ENDPATH**/ ?>
<?php if($client_messages->isNotEmpty()): ?>

    <?php $__currentLoopData = $client_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client_message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($client_message->seen==0): ?>
                <?php if(in_array($client_message->created_at->diffInSeconds(Carbon\Carbon::now(), false),range(0,2))): ?>
                    <li>
            <a href="<?php echo e(route('chat_user',$client_message->id)); ?>">
                <img src="<?php echo e(isset($client_message->getSender->image)&&file_exists('storage/'.$client_message->getSender->image)?asset('storage/'.$client_message->getSender->image):asset('website/images/avatar.png')); ?>" alt="img" />
                <div class="side-login">
                    
                    
                    <h3>قام <?php echo e($client_message->getSender->name); ?> بإرسال رسالة لك</h3>

                    <span class="login-time"><i class="far fa-clock"></i><?php echo e($client_message->created_at->diffForHumans()); ?>

                                                        </span>
                </div>
            </a>
        </li>
        <?php endif; ?>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?><?php /**PATH /home/harajplus/public_html/resources/views/website/load_msg.blade.php ENDPATH**/ ?>
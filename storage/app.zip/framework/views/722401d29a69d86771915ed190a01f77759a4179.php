<?php $__env->startSection('content'); ?>

<div class="container payment_porcedures">
    <?php echo \App\Models\StaticPages::find(4)->description; ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/website/payment_porcedures.blade.php ENDPATH**/ ?>
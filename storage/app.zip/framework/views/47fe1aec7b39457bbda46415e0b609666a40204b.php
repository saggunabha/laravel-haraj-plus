<?php $__env->startSection('content'); ?>
    <!--start products-title  -->
    <div class="favorites-title">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1>المفضلة</h1>
                </div>
            </div>
        </div>
    </div>
    <!--end Favorites-title  -->


    <div class="favorites-ps">
        <div class="container">
            <div class="row slider-products">
                <?php if(count($products) > 0): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="col-lg-4 col-md-6 col-sm-12 fav-col-grid">
                    <!--start product-grid-->
                    <div class="product-grid md-center">


                        <div class="product-div">
                            <div class="product-img">
                                <a  href="<?php echo e('/storage/' . $product->main_image); ?>" class="html5lightbox" data-group="set-1">

                                    <img src="<?php echo e('/storage/' . $product->main_image); ?>" alt="logo" />
                                </a>
                                <span  class="fav-icon first_bg active" id="<?php echo e($product->id); ?>" onclick="deleteFavourites(<?php echo e($product->id, auth()->id()); ?>)"><i class="far fa-heart"></i></span>
                            </div>
                            <a  href="<?php echo e(route('product-details',$product->id.'-'.$product->name)); ?>">
                                <div class="pavorites-text">
                                    <h3 class="product-name first_color"><?php echo e(strpos($product->name, '%') !== false ? str_replace("%","/",$product->name) : $product->name); ?>

</h3>
                                   <span class="new-price price"><?php echo e(isset($product->discount_ratio) ? $product->discount_ratio . ' ر.س  ': ''); ?></span>
                                   <span <?php if($product->discount_ratio != null): ?> class="old-price price" <?php endif; ?>><?php echo e($product->price . ' ر.س '); ?></span> 
                                </div>
                            </a>
                        </div>

                    </div>
                    <!--end product-grid-->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div>لا توجد منتجات في المفضلة</div>
                <?php endif; ?>








            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/website/favourite.blade.php ENDPATH**/ ?>
<?php $__env->startSection('pageTitle','حراج بلص'); ?>
<?php $__env->startSection('pageSubTitle', 'المنتجات'); ?>
<!--start main-content-->
<?php $__env->startSection('content'); ?>

    <!--start row-->
    <div class="raw">
        <div class="main-products-row row  no-marg-row col-12">
          
            <!--end div-->











            <!--end div-->

        </div>
        <div class="more-link-grid text-center col-12">
            <button class="more-link color-bg full-width-btn"  style="display:none" value='0'  onclick="loadmore()" id="loadmore">عرض المزيد</button>
        </div>


    </div>



<?php $__env->stopSection(); ?>
  <?php $__env->startSection('scripts'); ?>
      <script>




          $(document).ready(function(e){

                $(document).on("click",".more-text", function () {
                  $(this).next(".more-list").slideToggle("slow")
              });



        //   $(function () {


        //       var $winr = $(window); // or $box parent container
        //       var $boxr = $(".more-div");
        //       $winr.on("click.Bst", function (event) {
        //           if (
        //               $boxr.has(event.target).length === 0 && //checks if descendants of $box was clicked
        //               !$boxr.is(event.target) //checks if the $box itself was clicked
        //           ) {
        //           $boxr.find(".more-list").hide();

        //           }
        //       });
        //   });

              loadmore()
          });



          function loadmore() {


              var url = $('#loadmore').val();

              // console.log(url);

              if (url == 0) {

                  url = "/getMore?is_valid=<?php echo e((isset($_GET['is_valid'])&&$_GET['is_valid']==3)?3:1); ?>"
              }
              $.ajax({
                  url: url,
                  type: 'GET',
                  dataType: 'json',
                  success: function (data) {
                      $('.main-products-row').append(data['output'])
                      if (data['next_url'] == '') {
                          $('#loadmore').remove();

                      } else
                          $('#loadmore').val(data['next_url'])

                      $('#loadmore').show();

                  }
              });


          }



      </script>
      <script>

          $(document).on("click",".show_invalid_pro", function () {
             Swal.fire({
                    type: 'warning',
                    title: 'عفوا هذا المنتج غير مفعل',
                    showConfirmButton: false,
                    timer: 1500
                })
              });
    </script>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/products/index.blade.php ENDPATH**/ ?>
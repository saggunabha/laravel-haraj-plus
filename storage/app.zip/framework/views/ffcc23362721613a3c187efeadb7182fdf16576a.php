<?php $__env->startSection('pageTitle'); ?>لوحة التحكم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSubTitle'); ?> تعديل الاعدادات
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--start row-->
    <div class="row">
        <!--start div-->
        <div class="breadcrumbes col-12">
            <ul class="list-inline">
                <li><a href="<?php echo e(route('main')); ?>"><i class="fa fa-home"></i>الرئيسية</a></li>
                <li>تعديل الاعدادات</li>
            </ul>
        </div>
        <!--end div-->


        <!--start div-->
        <div class="col-md-12 clients-grid margin-bottom-div">
            <div class="main-white-box">
                <h3 class="sec-title color-title"><span>تعديل الاعدادات</span></h3>
                <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class="row border-form" id="myform" novalidate="" action="<?php echo e(route('update2')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                   <?php echo method_field('put'); ?>
                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        
                            
                            
                            
                                
                            

                        

                    <?php if($setting->type == 'url'): ?>
                        <div class="form-group  col-md-6">
                            <label><?php echo e($setting->name); ?><span class="starrisk">*</span></label>
                            <input type="url" class="form-control" name="<?php echo e($setting->key); ?>"   placeholder="الرابط" value="<?php echo e($setting->value); ?>" required>
                            <div class="invalid-feedback">
                                من فضلك أدخل رابط مناسب
                            </div>

                        </div>

                    <?php elseif($setting->type == 'tel'): ?>
                        <div class="form-group  col-md-6">
                            <label><?php echo e($setting->name); ?><span class="starrisk">*</span></label>
                            <input type="tel" class="form-control" name="<?php echo e($setting->key); ?>"   placeholder="الجوال" value="<?php echo e($setting->value); ?>" min="10" max="14" required>
                            <div class="invalid-feedback">
                                من فضلك أدخل رقم جوال مناسب
                            </div>

                        </div>

                    <?php elseif($setting->type == 'email'): ?>
                        <div class="form-group  col-md-6">
                            <label>البريد الاليكتروني<span class="starrisk">*</span></label>
                            <input type="email" class="form-control" name="<?php echo e($setting->key); ?>"     placeholder="البريد الاليكتروني" value="<?php echo e($setting->value); ?>"  required>
                            <div class="invalid-feedback">
                                من فضلك أدخل بريد اليكتروني مناسب
                            </div>

                        </div>

                    <?php elseif($setting->type == 'text'): ?>
                        <div class="form-group  col-md-6">
                            <label><?php echo e($setting->name); ?><span class="starrisk">*</span></label>
                            <input type="text" class="form-control" name="<?php echo e($setting->key); ?>"     placeholder="أدخل نص مناسب" value="<?php echo e($setting->value); ?>" required>
                            <div class="invalid-feedback">
                                من فضلك أدخل نص مناسب
                            </div>

                        </div>

                    <?php elseif($setting->type == 'number'): ?>
                        <div class="form-group  col-md-6">
                            <label><?php echo e($setting->name); ?><span class="starrisk">*</span></label>
                            <input type="<?php echo e($setting->type); ?>" class="form-control" name="<?php echo e($setting->key); ?>"     placeholder="أدخل رقم مناسب" value="<?php echo e($setting->value); ?>" step="any" required>
                            <div class="invalid-feedback">
                                من فضلك أدخل رقم مناسب
                            </div>

                        </div>

                    <?php elseif($setting->type == 'file'): ?>
                        <div class="form-group  col-md-6">
                            
                            <label><?php echo e($setting->name); ?><span class="starrisk">*</span></label>
                            <img src="<?php echo e(asset('storage/' . $setting->value)); ?>" alt="logo" style="width:200px; height:100px"/>


                                من فضلك ارفع صورة مناسبة


                        </div>


                    <?php endif; ?>



                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                    <div class="form-group  margin-top-div text-center col-12">
                        <button type="submit" class="more-link color-bg full-width-btn">حفظ</button>
                    </div>


                </form>
            </div>

        </div>
        <!--end div-->

    </div>
    <!--end row-->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('website/js/mapPlace.js')); ?>"></script>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDWZCkmkzES9K2-Ci3AhwEmoOdrth04zKs&libraries=places&callback=initMap&language=<?php echo e(App::getLocale()); ?>"
            async defer></script>
<?php $__env->stopSection(); ?>



<!-- scripts
     ================ -->




<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/settings/index.blade.php ENDPATH**/ ?>
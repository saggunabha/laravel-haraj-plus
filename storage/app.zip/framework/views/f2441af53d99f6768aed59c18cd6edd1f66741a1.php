<?php $__env->startSection('content'); ?>
    <div class="row">
        <!--start div-->
        <div class="breadcrumbes col-12">
            <ul class="list-inline">
                <li><a href="#"><i class="fa fa-home"></i>الرئيسية</a></li>
                <li>تفاصيل الطلب</li>
            </ul>
        </div>
        <!--end div-->



        <div class="col-md-12 clients-grid margin-bottom-div">
            <div class="main-white-box">
                <h3 class="sec-title color-title"><span>  تفاصيل الطلب</span></h3>





                <form  class="needs-validation row border-form" novalidate="">

                    <div class="form-group  col-md-6">
                        <label> اسم المحول <span class="starrisk">*</span></label>
                           <a href="<?php echo e(route('users.show',$payment->user_id)); ?>"  class=" btn form-control "
                      >
                            <?php echo e($payment->user->name); ?>

                        </a>
                    </div>



                    <div class="form-group  col-md-6">
                        <label> المبلغ المحول <span class="starrisk">*</span></label>
                        <input type="text" class="form-control" value="<?php echo e($payment->money_amount); ?>"   name="name"placeholder="الإسم  " readonly>

                    </div>



                    <div class="form-group  col-md-6">
                        <label> اسم البنك <span class="starrisk">*</span></label>
                        <input type="text" class="form-control" value="<?php echo e($bankAccount->name); ?>"   readonly>


                    </div>


                    <div class="form-group  col-md-6">
                        <label> رقم الحساب البنكى  <span class="starrisk">*</span></label>
                        <input type="text" class="form-control" value="<?php echo e($payment->bank_no); ?>"   readonly>

                    </div>

                    <div class="form-group  col-md-6">
                        <label>  نوع الباكدج <span class="starrisk">*</span></label>
                        <input type="text" class="form-control" value="<?php echo e(isset($payment->pakage)?$payment->pakage->type :'غير محدد'); ?>"   readonly>

                    </div>

                    <div class="form-group  col-md-6">
                        <label> الحاله <span class="starrisk">*</span></label>
                        <?php if($payment->is_accepted==2): ?>
                        <input type="text" class="form-control" value="قيد الانتظار"   readonly>
                            <?php elseif($payment->is_accepted==0): ?>
                            <input type="text" class="form-control" value="تم الرفض"   readonly>
                        <?php else: ?>
                            <input type="text" class="form-control" value="تم القبول"   readonly>
                        <?php endif; ?>

                    </div>

                    <div class="form-group  col-md-6">
                        <label> تاريخ التحويل<span class="starrisk">*</span></label>
                        <input type="date" class="form-control" value="<?php echo e($payment->transfer_date); ?>"    readonly>

                    </div>

                    




                    <div class="form-group  col-md-6">
                        <label> صوره الحواله<span class="starrisk">*</span></label>
                        <img src="<?php echo e(asset('storage/'.$payment->image)); ?>">

                    </div>







                    

                    <div class="form-group  margin-top-div text-center col-12">

                        <?php if($payment->is_accepted ==2): ?>
                            <a href="<?php echo e(route('businessmen.action',[$payment->id,1])); ?>" class="btn-success ">قبول</a>

                            <a href="<?php echo e(route('businessmen.action',[$payment->id,0])); ?>" class="remove-btn">رفض</a>
                        <?php endif; ?>
                    </div>



                </form>

            </div>

        </div>
    </div>
    <?php $__env->stopSection(); ?>


<?php $__env->startSection('footer'); ?>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/payments/details.blade.php ENDPATH**/ ?>
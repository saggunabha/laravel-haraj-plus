<?php $__env->startSection('meta'); ?>
    <meta property="og:title" content="<?php echo e($user->user->name); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:image:url"  content="<?php echo e(asset('storage/'.$user->user->image)); ?>" />
    <meta property="og:image:width"  content="600" />
    <meta property="og:image:height"  content="314" />
    <meta property="og:description" content="<?=strip_tags($user->about)?>" />
    <meta property="og:site_name" content="حراج بلص" />
    <meta property="fb:app_id" content="1909299302714716" />
   
    <meta name="twitter:card" content="summary" />
    <meta name="twitter:site" content="حراج بلص" />
    <meta name="twitter:creator" content="www.jaadara.com" />
    <meta property="og:url" content="<?php echo e(route('business-general-profile',$user->link)); ?>"/>
    <meta property="og:title" content="<?php echo e($user->user->name); ?>" />
    <meta property="og:description" content="<?=strip_tags($user->about)?>" />
    <meta property="og:image" content="<?php echo e(asset('storage/'.$user->user->image)); ?>" />
    <script type="application/ld+json">
        {
            "@context": "http://schema.org",
            "@type": "Person",
            "name": "<?php echo e($user->user->name); ?>",
            "image":"<?php echo e(asset('storage/'.$user->user->image)); ?>",
            "disambiguatingDescription": "<?php echo e($user->about); ?>"
        }
        
        </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('seoTitle', $user->user->name); ?>
<?php $__env->startSection('seoDescription', strip_tags($user->about) ); ?>
<?php $__env->startSection('seoKeywords', ($user->user->name)); ?>
<?php $__env->startSection('seoGoogleImg', asset('storage/'.$user->user->image)); ?>
<?php $__env->startSection('content'); ?>

    <section class="order-div page-order-div">
        <div class="profile-pg">
            <div class="container-fluid">
                <div class="row">
                    <!--start profile-images-->
                    <div class="profile-images-grid col-12 no-marg-row wow fadeIn">

                        <div class="form-group profile-image-upload">
                            <input type="file" class="img-form-shape file-input form-control" value="" id="main-01"
                                   disabled>

                            <label class="file-input-label timeline-label full-width-img " for="main-01"> <img
                                    src="<?php echo e(asset('storage/'.$user->cover_image)); ?>" alt="img" class="converted-img" />
                                <img id="preview-main-01" />
                            </label>


                            <div class="user-profile-img">
                                <input type="file" class="img-form-shape file-input form-control" value="" id="main-02"
                                       disabled>


                                <label class="file-input-label timeline-label full-width-img " for="main-02"> <img
                                        src="<?php echo e(asset('storage/'.$user->user->image)); ?>" alt="img" class="converted-img" />
                                    <img id="preview-main-02" />
                                </label>
                            </div>
                        </div>
                    </div>
                    <!--end profile-images-->
                </div>
            </div>

            <div class="container">
                <div class="row">


                    <div class="col-12 text-center wow fadeIn">
                        <div class="store-information-text">
                            <h2 class="info-title first_color">نبذة عن <?php echo e($user->user->name); ?></h2>
                            <p>
                                <?php echo e($user->about); ?>

                            </p>
                        </div>
                    </div>

                    <div class="col-12 two-btns  margin-div text-left-dir wow fadeIn">

                        <a  href="<?php echo e(route("chatStore",$user->user->id)); ?>"  <?php if(!auth()->id()): ?>   data-toggle="modal" data-target="#login-modal"   <?php endif; ?> class="custom-btn big-btn">راسلنا</a>
                        <br>
                        <a  href="https://api.whatsapp.com/send?phone=<?php echo e($user->user->phone); ?>"  class="custom-btn big-btn">للتواصل عبر الواتس اب</a>


                    </div>
                </div>

            </div>

        </div>
        <!--start rate-model -->

        <!-- end rate-model -->


        <!-- start products
         ================ -->
        <div class="products md-center margin-div products-pg profile-products   wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <h2 class="sec-title text-center"> المنتجات</h2>
                    </div>
                    <div class="col-12 text-left-dir sm-center">

                        <div class="product-contact-btns col-12 xs-center">
                            <?php if(isset($user->phone)): ?>
                                <span class="main-white-box"><i class="fab fa-whatsapp"></i>التواصل
                                    باستخدام
                                    الواتساب
                                    <a  href="https://wa.me/?text=<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a>
                                </span>
                            <span class="main-white-box"><i class="fa fa-phone"></i>قم
                                    بالاتصال
                                    الآن
                                    <a  href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a>
                                </span>

<?php endif; ?>
                        </div>

                        <div class="share-social">
                            <span class="first_color info-title"> مشاركة </span>
                            <div class="share-social">
                                <ul class="list-inline auto-icon">
                                    <div class="sharethis-inline-share-buttons"></div>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="row no-marg-row col-12">
                        <!--start item-->


<?php if(!$products->isEmpty()): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item col-xl-3 col-lg-4 col-6 load-div ">
                            <!--start product-grid-->
                            <div class="product-grid">
                                <div class="product-div">
                                    <?php if(auth()->id()): ?>
                                        <?php if($favouriteProducts!=[] ): ?>

                                            <span <?php if(in_array($product->id,$favouriteProducts)): ?> class="fav-icon first_bg active" <?php else: ?>  class="fav-icon first_bg " <?php endif; ?>  ><i class="far fa-heart"></i></span>
                                        <?php else: ?>
                                            <span class="fav-icon first_bg">

                                          <i class="far fa-heart"></i>
                                      </span>
                                        <?php endif; ?>
                                    <?php endif; ?>


                                    <a  href="<?php echo e(route('product-details',$product->id.'-'.$product->name)); ?>">
                                        <div class="product-img">
                                            <img src="<?php echo e(asset('storage/'.$product->main_image)); ?>" alt="logo" />
                                        </div>
                                        <div class="product-details">
                                            <h3 class="product-name first_color"><?php echo e($product->name); ?> </h3>
                                            <?php if($product->discount_ratio): ?>

                                            <span class="new-price price"><?php echo e($product->price-$product->price*$product->discount_ratio/100); ?> ر.س</span>
                                            <span class="old-price price"><?php echo e($product->price); ?> ر.س</span>
                                        <?php else: ?>
                                            <span class="new-price price"><?php echo e($product->price); ?> ر.س</span>
                                        <?php endif; ?>
                                            <div class="two-btns">
                                                <button class="custom-btn sm-btn">إشتري الأن</button>
                                                <span class="product-time second_bg first_color"> <?php echo e($product->created_at->diffForHumans(Carbon\Carbon::now(), false)); ?> </span>
                                            </div>
                                        </div>
                                    </a>
                                    <span class="pointer-shadow"></span>

                                </div>
                            </div>
                            <!--end product-grid-->
                        </div>
                        <!--end item-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($count>12): ?>
                                <div class="text-center col-12 margin-div">
                                    <a  href="#" class="custom-btn big-btn" id="loadmore">المزيد</a>
                                </div>
                            <?php endif; ?>
<?php else: ?>

                            <h4 class='empty-div-messages text-center'>لا يوجد منتجات</h4>

<?php endif; ?>
                    </div>
                </div>


            </div>
        </div>
        <!--end products-->

    </section>
    <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type='text/javascript' src='https://platform-api.sharethis.com/js/sharethis.js#property=5e9e29a0e3a49d0012075ee9&product=image-share-buttons&cms=website' async='async'></script>

    <script>

        $(".product-contact-btns .main-white-box").click(function () {
            $(".product-contact-btns .main-white-box").removeClass("active");
            $(this).addClass("active");
        });
    $(function () {
    $(".load-div").slice(0, 12).fadeTo("slow", 1);

    $("#loadmore").on('click', function (e) {
    e.preventDefault();
    $(".load-div:hidden").slice(0, 12).slideDown("fast");

    if ($(".load-div:hidden").length == 0) {
    $("#loadmore").fadeOut('fast');
    } else {
    $("#loadmore").fadeIn('fast');

    }
    $('html,body').animate({
    scrollTop: $(this).offset().top - 600
    }, 1500);
    });
    });


</script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/website/general-profile.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>

 <?php $payment = \App\Models\Payment::where([
    ['user_id',\Auth::id()],['is_accepted',2]
])->get(); ?>
<?php if(!count($payment)): ?>
<!-- start title Package -->
<div class="title-Package">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1>الباقات المتوفرة</h1>
                <?php if(isset($data->description)): ?>
                <p><?php echo $data->description; ?></p>
                <?php endif; ?>
            </div>
            <div class="col-lg-12">
                <div class="sup-package">
                    <button class="but1">شهرية</button>
                    <button class="but2">سنوية</button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- start-Offers-package -->
<div class="Offers-package">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4  col-md-6">
                <div class="main-Offers-package">
                    <h2><?php echo e($package->type); ?></h2>
                    <h4><?php echo e($package->price); ?> <span>رس</span></h4>
                    <h3><?php echo e($package->duration . ' يوم '); ?></h3>
                   <ul class="list-unstyled">
                       <li><?php echo $package->body; ?></li>
                   </ul>
                    <?php if($package->duration!=0): ?>
                    <a  href="<?php echo e(route('paymentMethods',$package->id)); ?>" class="custom-btn">اشترك الآن</a>
              <?php endif; ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




        </div>
    </div>
</div>
<?php else: ?>
    <div class="alert alert-info" style="position: relative;top: 100px">
        <strong>طلبك قيد المراجعة وسيتم الرد عليكم فى خلال 48 ساعة</strong>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/website/package.blade.php ENDPATH**/ ?>
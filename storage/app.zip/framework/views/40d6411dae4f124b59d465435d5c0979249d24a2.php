<?php $__env->startSection('meta'); ?>
 
<script type="application/ld+json">
{
 "@context": "http://schema.org/",
 "@type": "CategoryCodeSet",
 "@id": "<?php echo e(isset($category)?$category->id :''); ?>",
 "name": "<?php echo e(isset($category)?$category->name:''); ?>",
 "image":"<?php echo e(isset($category)?asset('storage/'.$category->image):''); ?>",
 "hasCategoryCode": {
        "@type": "CategoryCode",
        "name": "<?php echo e(isset($category)?$category->name:''); ?>",
        "description": "<?php echo e(isset($category)?$category->name:''); ?>",
        "inCodeSet": "<?php echo e(isset($category)?$category->id:''); ?>"
        }
}
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!--start product-details-pg
          ================-->

   <div class="dark-gray-bg">
    <section class="order-div page-order-div">

        <!-- start products
         ================ -->
        <section class="products md-center margin-div products-pg  responsive-margin-div  wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-12">

                        <?php if(\Route::currentRouteName()!='products.search'): ?>
                            <h2 class="sec-title text-center"> المنتجات</h2>
                            <?php else: ?>
                            <h2 class="sec-title text-center"> نتائج البحث </h2>
                            <?php endif; ?>

                    </div>

                    <div class="row no-marg-row col-12">
                        <!--start item-->

                        <?php if($allProducts->isNotEmpty()): ?>
                        <?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                            <div class="item col-xl-3 col-lg-4 col-6 load-div ">
                                <!--start product-grid-->
                                <div class="product-grid">
                                    <div class="product-div">
                                        <?php if(auth()->id()): ?>
                                            <?php if($favouriteProducts!=[] ): ?>

                                                <span <?php if(in_array($product->id,$favouriteProducts)): ?> class="fav-icon first_bg active" onclick="togFav(<?php echo e($product->id, auth()->id()); ?>)" <?php else: ?>  class="fav-icon first_bg " onclick="togFav(<?php echo e($product->id, auth()->id()); ?>)" <?php endif; ?>  ><i class="far fa-heart"></i></span>
                                            <?php else: ?>
                                                <span class="fav-icon first_bg" onclick="togFav(<?php echo e($product->id, auth()->id()); ?>)">

                                          <i class="far fa-heart"></i>
                                      </span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                        <a  href="<?php echo e(route('product-details',$product->id.'-'.$product->name)); ?>">
                                            <div class="product-img">
                                                <img src="<?php echo e(asset('storage/'.$product->main_image)); ?>" alt="logo" />
                                            </div>
                                            <div class="product-details">
                                                
                                                <h3 class="product-name first_color"><?php echo e(strpos($product->name, '%') !== false ? str_replace("%","/",$product->name) : $product->name); ?> </h3>
                                                <?php if(isset($product->discount_ratio)): ?>
                                                <span class="new-price price"><?php echo e($product->price-$product->price*$product->discount_ratio/100); ?> ر.س</span>
                                                <span class="old-price price"><?php echo e($product->price); ?> ر.س</span>
                                                <?php else: ?>
                                                <span class="new-price price"><?php echo e($product->price); ?> ر.س</span>
                                                
                                                <?php endif; ?>
                                                <div class="two-btns">
                                                     <button class="custom-btn sm-btn">الشراء
                                                    الأن</button>
                                                    <span class="product-time second_bg first_color"> <?php echo e($product->created_at->diffForHumans(Carbon\Carbon::now(), false)); ?></span>
                                                </div>
                                            </div>
                                        </a>
                                        <span class="pointer-shadow"></span>

                                    </div>
                                </div>
                                <!--end product-grid-->
                            </div>
                            <!--end item-->
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>

                <?php if($count>12): ?>
                <div class="text-center col-12 margin-div">
                    <a  class="custom-btn big-btn" id="loadmore">المزيد</a>
                </div>
                    <?php endif; ?>

                <?php endif; ?>

               <?php if($allProducts->isEmpty()): ?>
                    <?php if(\Route::currentRouteName()=='website.products'): ?>
                    <h1 class="empty-div-messages text-center">لا يوجد منتجات</h1>
                    <?php else: ?>
                        <h4 class="empty-div-messages text-center">لم ينجح بحثك, ربما المنتجات التي تريد الوصول لها غير متوفرة</h4>
                    <?php endif; ?>
                    </div>
                 <?php endif; ?>


        </section>
        <!--end products-->


    </section>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('scripts'); ?>
    <script>
        //load div
        $(function () {
            $(".load-div").slice(0, 18).fadeTo("slow", 1);

            $("#loadmore").on('click', function (e) {
                e.preventDefault();
                $(".load-div:hidden").slice(0, 18).slideDown("fast");

                if('load-div')

                if ($(".load-div:hidden").length == 0) {
                    $("#loadmore").fadeOut('fast');
                } else {
                    $("#loadmore").fadeIn('fast');

                }
                $('html,body').animate({
                    scrollTop: $(this).offset().top - 600
                }, 1500);
            });
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/website/products.blade.php ENDPATH**/ ?>
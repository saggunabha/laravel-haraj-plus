<?php $__env->startSection('pageTitle','حراج بلص'); ?>
<?php $__env->startSection('pageSubTitle', 'المستخدمين'); ?>
<!--start main-content-->
<?php $__env->startSection('content'); ?>

            <!--start row-->
            <div class="row">
                <!--start div-->
                <div class="breadcrumbes col-12">
                    <ul class="list-inline">
                        <li><a href="#"><i class="fa fa-home"></i>الرئيسيه</a></li>
                        <li>العملاء</li>
                    </ul>
                </div>
                <!--end div-->


                <!--start div-->
                <div class="col-md-12 clients-grid margin-bottom-div">
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success alert-styled-left">
                            <button type="button" class="close" data-dismiss="alert"><span>×</span><span class="sr-only">Close</span></button>
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>

   
                    <button type="button" class="btn btn-primary" id="button-send" data-toggle="modal" data-target="#exampleModal"  data-whatever="العملاء">
                        ارسال رسالة
                    </button>
                    
                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">رسالة جديدة</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <form>  
                            <input type="hidden" class="form-control" value="<?php echo e(route('send-bussiness')); ?>" id="action">
                              <div class="form-group">
                                <label for="message-text" class="col-form-label">الرسالة:</label>
                                <textarea class="form-control" id="message-text"></textarea>
                              </div>
                            </form>
                          </div>
                          <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">إغلاق</button>
                            <button type="button" class="btn btn-primary" id="send-all">إرسال</button>
                          </div>
                        </div>
                      </div>
                    </div>

                    <table id="example" class="table table-striped table-bordered dt-responsive nowrap"
                           style="width:100%">
                        <thead>
                        <tr>
                            <th>#ID</th>
                            <th>اسم العميل</th>
                            <th>الجوال</th>
                            <th>البريد الإلكتروني</th>
                            <th>النوع</th>
                            <th>الحاله</th>
                            <th>تاريخ التسجيل</th>
                            <th> الاجراء المتخد</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $i=1;?>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?>

                                <input type="checkbox" class="send-message" name="users[]" value="<?php echo e($user->id); ?>"></td>

                            </td>
                            <td>
                            <a href="<?php echo e(route('user-profile',$user->id.'-'.$user->name)); ?>">
                            <img  <?php if($user->image): ?>src="<?php echo e(asset('storage/'.$user->image)); ?>" <?php else: ?>  src="<?php echo e(asset('admin/images/main/avatar.png')); ?>" <?php endif; ?>  alt="client"><?php echo e($user->name); ?>

                            </a>
                            </td>
                            <td><?php echo e($user->phone); ?></td>
                            <td><?php echo e($user->email); ?></td>
                            <td><?php echo e($roles[$user->type]); ?></td>
                            <?php if($user->is_active==1): ?>
                            <td>مفعل</td>
                            <?php else: ?>
                                <td>تم تجميده</td>
                                <?php endif; ?>
                            <td><?php echo e($user->created_at->format("d/m/Y")); ?></td>
                            <td>
                                <a href="<?php echo e(route('users.edit',$user->id)); ?>" class="edit-btn-table"><i class="fa fa-edit"></i></a>

                             <!--  <a title="delete" onclick="return false;" object_id="<?php echo e($user->id); ?>" delete_url="/users/"
                                  class="edit-btn-table remove-alert" href="#">
                                <i class="fa fa-times"></i> </a>-->
                            </td>
                        </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





                        </tbody>
                    </table>

                </div>
                <!--end div-->


            <!--end row-->

    </div>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<script>
 
$('#button-send').click(function () {
  var atLeastOneIsChecked = $('input:checkbox').is(':checked');
  if(!atLeastOneIsChecked){
  $('#button-send').attr('disabled', true);
  Swal.fire({
                       type: 'warning',
                       title: 'قم باختيار مستخدم واحد علي الاقل',
                       showConfirmButton: false,
                       timer: 1500
                   })
  window.location.reload();
  }
});

$('#exampleModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) 
    var modal = $(this)
    modal.find('.modal-title').text('رسالة جديدة الي رجال الاعمال ')
  })

</script>


<script>


$('#send-all').click(function(event){
   
   event.preventDefault();
   var arr=[];
   $.each($("input[name='users[]']:checked"), function () {
   arr.push( this.value)
   });
   var message = $('#message-text').val();
   var action = $('#action').val();
   var token=$('meta[name="csrf-token"]').attr('content');

   $.ajax({
   url : action,
   type:'POST',
   dataType: "json",
   data:{"users":arr , "message":message,"_token":token},
   success: function(response) {
       if(response['success']){
              Swal.fire({
                       type: 'success',
                       title: 'تم إرسال الرسالة بنجاح',
                       showConfirmButton: false,
                       timer: 1500
                   })
                   $('#message-text').val('');
                   location.reload();
                   $('#exampleModal').modal('toggle');
       }else{
           Swal.fire({
                       type: 'error',
                       title: 'عفوا يوجد خطأ',
                       showConfirmButton: false,
                       timer: 1500
                   })
                   $('#message-text').val('');
                   $('#exampleModal').modal('toggle');
       }

   }

});
});
  </script>  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/members/index.blade.php ENDPATH**/ ?>
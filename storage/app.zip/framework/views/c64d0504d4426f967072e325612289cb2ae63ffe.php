<!--start div-->
<?php if($products->isEmpty()): ?>
    <div class="more-link-grid text-center col-12">
        <span class="more-link color-bg full-width-btn"> لا توجد منتجات </span>
    </div>
<?php else: ?>

    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-lg-4 col-md-6 products-grid  ">
            <div class="product-div">
                <div class="product-img">
                    <a href="<?php echo e(asset("storage/".$product->main_image)); ?>" class="html5lightbox" data-group="set-0">
                        <img src="<?php echo e(asset("storage/".$product->main_image)); ?>" alt="product" />
                    </a>
                </div>

                <div class="product-details">
                    <form class="needs-validation" novalidate>
                        <div class="row no-marg-row">
                            <div class="col-12">
                                <div class="pro-main-details">
                                    <div class="pro-det form-control">  الاسم:<?php echo e($product->name); ?>   </div>
                                    <i class="fa fa-file-alt"></i>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="pro-main-details">
                                    <div class="pro-det form-control">السعر : <?php echo e($product->price); ?>ريال</div>
                                    <i class="fa fa-money-bill-alt"></i>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="pro-main-details">
                                    <div class="pro-det form-control">
                                <?php if($product->is_valid==1): ?>
                                <?php elseif($product->is_valid==3): ?> بانتظار التفعيل 
                                <?php else: ?> تم تجميده
                                <?php endif; ?>
                                </div>
                                    <i class="fa fa-money-bill-alt"></i>
                                </div>
                            </div>

                            

                            <div class="col-md-12">
                                <div class="pro-main-details">
                                    <div class="pro-det form-control"> القسم : <?php echo e($product->category->name); ?>  </div>
                                    <i class="fa fa-file-archive"></i>
                                </div>
                            </div>



            <div class="col-12">
                <div class="more-div left-text-dir">
                                    <span class="more-text">المزيد <i
                                            class="fa fa-chevron-left"></i></span>
                    <div class="more-list">
                        <ul class="list-unstyled">

                            <?php if($product->user_id!=auth()->id()): ?>
                            <li><a href="<?php echo e(route('chatUserPro',$product->id)); ?>" ><i
                                        class="fa fa-envelope"></i> مراسله صاحب المنتج</a></li>
                            <?php endif; ?>
                            <?php if($product->is_valid==3): ?>
                            <li><a href="<?php echo e(route("products.activate",$product->id)); ?>"><i
                                        class="fa fa-edit"></i>تفعيل المنتج</a></li>
                            <?php endif; ?>
                            <li><a href="<?php echo e(route("products.edit",$product->id)); ?>"><i
                                        class="fa fa-edit"></i>تعديل المنتج</a></li>
                                        <?php if($product->is_valid ==3): ?>
                            <li class="show_invalid_pro"><a href="#"><i
                                        class="fa fa-eye"></i>عرض المنتج</a></li>
                                        <?php else: ?> 
                                        <li><a href="<?php echo e(route("product-details",$product->id.'-'.$product->name)); ?>"><i
                                            class="fa fa-eye"></i>عرض المنتج</a></li>
                                        <?php endif; ?>
                            <li><a href="<?php echo e(route("deleteProduct",$product->id)); ?>"><i
                                        class="fa fa-trash"></i>حذف المنتج</a></li>


                        </ul>
                    </div>
                </div>
            </div>

                        </div>
                    </form>
                </div>

            </div>
        </div>
        <!--end div-->

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php endif; ?>
<?php /**PATH /home/harajplus/public_html/resources/views/admin/products/read_more.blade.php ENDPATH**/ ?>
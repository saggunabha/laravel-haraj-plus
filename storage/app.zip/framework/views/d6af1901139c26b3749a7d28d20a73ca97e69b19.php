<?php if($allProducts->isNotEmpty()): ?>
<?php $__currentLoopData = $allProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <!--start item-->
    <div class="item m-2">
        <!--start product-grid-->
        <div class="product-grid">
            <div class="product-div"> 
                <?php if(auth()->id()): ?>
                    <?php if($favouriteProducts!=[] ): ?>
                        <span
                            <?php if(in_array($product->id,$favouriteProducts)): ?> class="fav-icon first_bg active"
                            onclick="toggleFavourites(<?php echo e($product->id, auth()->id()); ?>)"
                            <?php else: ?>  class="fav-icon first_bg "
                            onclick="toggleFavourites(<?php echo e($product->id, auth()->id()); ?>)" <?php endif; ?>  ><i
                                class="far fa-heart"></i></span>
                    <?php else: ?>
                        <span onclick="toggleFavourites(<?php echo e($product->id, auth()->id()); ?>)"
                                class="fav-icon first_bg">
                    <i class="far fa-heart"></i>
                </span>
                        <?php endif; ?>
                <?php endif; ?>
                <a  href="<?php echo e(route('product-details',$product->id.'-'.$product->name)); ?>">
                    <div class="product-img">
                        <img src="<?php echo e(asset('storage/'.$product->main_image)); ?>" alt="logo"/>
                    </div>
                    <div class="product-details">
                        <h3 class="product-name first_color"><?php echo e(strpos($product->name, '%') !== false ? str_replace("%","/",$product->name) : $product->name); ?>

</h3>
                        <?php if($product->discount_ratio): ?>
                            <span class="new-price price"><?php echo e($product->price-$product->price*$product->discount_ratio/100); ?> ر.س</span>
                            <span class="old-price price"><?php echo e($product->price); ?> ر.س</span>
                        <?php else: ?>
                            <span class="new-price price"><?php echo e($product->price); ?> ر.س</span>
                        <?php endif; ?>
                        <div class="two-btns">
                            <button class="custom-btn sm-btn">الشراء الان</button>
                            <span
                                class="product-time second_bg first_color"> <?php echo e($product->created_at->diffForHumans(Carbon\Carbon::now(), false)); ?></span>
                        </div>
                    </div>
                </a>
                <span class="pointer-shadow"></span>

            </div>
        </div>
        <!--end product-grid-->
    </div>
    <!--end item-->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /home/harajplus/public_html/resources/views/website/appendProducts.blade.php ENDPATH**/ ?>
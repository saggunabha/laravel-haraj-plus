<div class="fixed-menu-grid" id="dark-scroll">
    <div class="fixed-menu">
        <span class="collapse-menu-icon"><i class="fas fa-arrow-right"></i></span>
        <div class="logo-title">
            <img src="<?php echo e(asset('/website/images/main/logo.png')); ?>" alt="img"/>
            <div class="side-logo-title">
                حراج بلص
                <a href="<?php echo e(route('home')); ?>" class="color-hover">زياره الموقع</a>
            </div>
        </div>
        <div class="main-menu">
            <ul class="list-unstyled">
               <li <?php if(\Request::segment(2)=='index'): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('main')); ?>" title="الرئيسية"><i
                            class="fa fa-home"></i><span>الرئيسية</span></a></li>


                    <li <?php if(\Request::segment(2)=='users'): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('users.index')); ?>" title="العملاء"><i
                            class="fa fa-users"></i><span>العملاء</span></a></li>

                    <li <?php if(\Request::segment(2)=='businessmen'): ?> class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('businessmen')); ?>" title="العملاء"><i
                            class="fa fa-users"></i><span>رجال الاعمال</span></a></li>
               <li <?php if(\Request::segment(2)=='products'&&!isset($_GET['is_valid'])): ?> class="active" <?php endif; ?>>

                    <a href="<?php echo e(route('products.index')); ?>" title="المنتجات"><i
                            class="fa fa-car"></i><span>المنتجات</span></a>
               </li>
                <li class="<?php echo e((isset($_GET['is_valid'])&&$_GET['is_valid']==3)?'active':''); ?>">

                    <a  href="<?php echo e(route('products.index')); ?>?is_valid=3" title="المنتجات"><i
                            class="fa fa-car"></i><span>المنتجات قيد المراجعة</span></a>
                </li>



              <li <?php if(\Request::segment(2)=='payments'): ?>  class="active" <?php endif; ?>>

                    <a href="<?php echo e(route('payments.index')); ?>" title="طلبات الترقيه"><i
                            class="fa fa-car"></i><span>طلبات الترقيه</span></a></li>



                <li>




               <li <?php if(\Request::segment(2)=='brands'): ?>  class="active" <?php endif; ?>>

                    <a href="<?php echo e(route('brands.index')); ?>" title="الماركات"><i
                            class="fa fa-car"></i><span>الماركات</span></a>
                </li>

                <li <?php if(\Request::segment(2)=='countries'): ?>  class="active" <?php endif; ?>>


                    <a href="<?php echo e(route('countries.index')); ?>" title="الدول"><i
                            class="fa fa-flag"></i><span>الدول</span></a>
                </li>

                 <li <?php if(\Request::segment(2)=='cities'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('cities.index')); ?>" title="المدن"><i
                            class="fa fa-home"></i><span>المدن</span></a>
                </li>

              <li <?php if(\Request::segment(2)=='categories'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('categories.index')); ?>" title="الأقسام الرئيسية"><i
                            class="fa fa-tshirt"></i><span>الأقسام الرئيسية</span></a>
                </li>

                <li <?php if(\Request::segment(2)=='sub-categories'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('sub-categories.index')); ?>" title=" الأقسام الفرعية"><i
                            class="fa fa-ice-cream"></i><span>الأقسام الفرعية</span></a>
                </li>

                 <li <?php if(\Request::segment(2)=='sliders'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('sliders.index')); ?>" title="السلايدرز"><i class="fa fa-arrows-alt-h"></i><span>السلايدرز</span></a>


                 <li <?php if(\Request::segment(2)=='ads'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('ads.index')); ?>" title="الاعلانات"><i
                            class="fa fa-ad"></i><span>الاعلانات</span></a>
                </li>

              <li <?php if(\Request::segment(2)=='bank-accounts'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('bank-accounts.index')); ?>" title="الحسابات البنكية"><i
                            class="fa fa-money-check"></i><span>الحسابات البنكية
                                            </span></a>
                </li>



                <li <?php if(\Request::segment(2)=='contacts'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('contacts.index')); ?>" title="الاتصالات"><i
                            class="fa fa-phone"></i><span>الاتصالات</span></a>

                </li>


               <li <?php if(\Request::segment(2)=='packages'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('packages.index')); ?>" title="الباقات"><i
                            class="fa fa-box"></i><span>الباقات</span></a>
                </li>

                <li <?php if(\Request::segment(2)=='reports'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('reports.index')); ?>" title="البلاغات عن المنتجات"><i
                            class="far fa-hand-paper"></i><span>البلاغات عن المنتجات</span></a>
                </li>


                <li <?php if(\Request::segment(2)=='comment-reports'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('commentReports')); ?>" title="البلاغات عن التعليقات"><i
                                class="far fa-hand-paper"></i><span>البلاغات عن التعليقات</span></a>
                </li>


                               <li <?php if(\Request::segment(2)=='subscribers'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('subscribers.index')); ?>" title="القائمة البريدية"><i
                            class="fa fa-envelope"></i><span>القائمة البريدية</span></a>
                </li>

               <li <?php if(\Request::segment(2)=='static-pages'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('static-pages.index')); ?>" title="الصفحات الثابتة"><i
                            class="fa fa-copy"></i><span>الصفحات الثابتة</span></a>
                </li>

                <li <?php if(\Request::segment(2)=='techs'): ?>  class="active" <?php endif; ?>>
                        <a href="<?php echo e(route('techs.index')); ?>" title="رسائل الدعم الفني"><i
                         class="fas fa-envelope"></i><span>رسائل الدعم الفني</span></a>
                    </li>


               <li <?php if(\Request::segment(2)=='settings'): ?>  class="active" <?php endif; ?>>
                    <a href="<?php echo e(route('settings.index')); ?>" title="إعدادات
                                            الموقع"><i class="fa fa-cog"></i><span>إعدادات
                                            الموقع</span></a>
                </li>
              


            </ul>


        </div>
    </div>
</div>
<!--end div-->
<?php /**PATH /home/harajplus/public_html/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>
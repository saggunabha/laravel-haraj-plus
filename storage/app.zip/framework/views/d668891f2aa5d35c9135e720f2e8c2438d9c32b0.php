

<?php if($products->isNotEmpty()): ?>
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="item col-xl-3 col-lg-4 col-6 ">
        <!--start product-grid-->
        <div class="product-grid">
            <div class="product-div ads-prod">

                <a  href="<?php echo e(route('product-details',$product->id.'-'.$product->name)); ?>">
                    <div class="product-img">
                        <img src="<?php echo e(asset('storage/'.$product->main_image)); ?>" alt="logo" />
                    </div>
                    <div class="product-details">
                        <h3 class="product-name first_color"><?php echo e(strpos($product->name, '%') !== false ? str_replace("%","/",$product->name) : $product->name); ?>

 </h3>
                        <?php if($product->discount_ratio != null): ?>
                            <span class="new-price price"><?php echo e($product->price-($product->price*$product->discount_ratio)/100); ?> ر.س</span>
                            <span class="old-price price"><?php echo e($product->price); ?> ر.س</span>
                        <?php else: ?>
                            <span class="new-price price"><?php echo e($product->price); ?> ر.س</span>
                        <?php endif; ?>
                        <div class="two-btns">

                            <?php if($product->is_valid==1): ?>
                                <button class="custom-btn sm-btn">مفعل</button>
                            <?php elseif($product->is_valid==0): ?>
                                <button class="custom-btn sm-btn">تم تجميده</button>
                                <?php else: ?>
                                <button class="custom-btn sm-btn">قيد الانتظار </button>
                            <?php endif; ?>
                            <span class="product-time second_bg first_color"><?php echo e($product->created_at->diffForHumans(Carbon\Carbon::now(), false)); ?></span>
                        </div>
                    </div>
                </a>
                <div class="edit-prouct-icons">
                    <a  href="<?php echo e(route('product.change',$product->id)); ?>" title="تعديل"><i class="fa fa-edit"></i></a>
                    <?php if($product->is_valid==1): ?>
                        <a  href="<?php echo e(route('products.deactivate',$product->id)); ?>" title="تجميد"><i class="fa fa-cube"></i></a>

                    <?php elseif($product->is_valid==0): ?>

                            <a  href="<?php echo e(route('products.deactivate',$product->id)); ?>" title="تفعيل"><i class="fas fa-retweet"></i></a>

                    <?php endif; ?>
                    <a  title="delete" onclick="return false;" object_id="<?php echo e($product->id); ?>" delete_url="/products/delete/"
                       class="edit-btn-table remove-alert-website" href="#">
                        <i class="fa fa-times"></i> </a>

                </div>

            </div>
        </div>
        <!--end product-grid-->
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
    <h4 class='empty-div-messages text-center'>لا يوجد منتجات</h4>
<?php endif; ?>

<?php /**PATH /home/harajplus/public_html/resources/views/website/load.blade.php ENDPATH**/ ?>
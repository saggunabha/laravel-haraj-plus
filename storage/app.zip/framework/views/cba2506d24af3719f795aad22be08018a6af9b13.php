<!-- start header
     ================ -->
<header><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <div class="container">
        <div class="row">
            <!--start div-->
            <div class="col-lg-8  col-md-7 sm-center main-search-grid">
                <div class="main-search">
                    <form class="needs-validation" method="post"  action="<?php echo e(route('admin.search')); ?>" novalidate>
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <input class="form-control main-input"  name="name" placeholder="بحث..." required />
                            <div class="invalid-feedback">
                                من فضلك إدخل نص صحيح
                            </div>


                            <button type="submit" class="color-bg-hover"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
            <!--end div-->


            <!--start div-->
            <div class="col-lg-4 col-md-5 left-text-dir sm-center  main-user-grid">
                <div class="user-div">
                    <!--<span class="user-title color-hover"><i class="fa fa-bell"></i>الرسائل <?php if($count_clientMsg>0): ?><b><?php echo e($count_clientMsg); ?></b> <?php endif; ?></span>-->
                    
                    <span  class="user-title color-hover" id="message_count"><i class="fa fa-bell"></i>الرسائل</span>

                    <div class="user-list notifications-div" id="dark-scroll">
                        <ul class="list-unstyled">
 
                            <?php if(isset($client_messages) &&$client_messages->isNotEmpty()): ?>
                         
                                <?php $__currentLoopData = $client_messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client_message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <li>

                                        <a href="<?php echo e(route('chatUser',$client_message->getSender->id)); ?>">
                                            <div class="full-width-img main-notify-img">
                                                <img src="<?php echo e(isset($client_message->getSender->image)&&file_exists('storage/'.$client_message->getSender->image)?asset('storage/'.$client_message->getSender->image):asset('website/images/avatar.png')); ?>" class="converted-img" alt="img" />
                                            </div>
                                            <h3><?php echo e($client_message->getSender->name); ?></h3>
                                            <span class="time"><?php echo e($client_message->created_at->diffForHumans()); ?></span>
                                            <p><?php echo e($client_message->content); ?></p>
                                        </a>

                                    </li>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <li >
                                   <p style="color: white">لا يوجد رسائل</p>
                                </li>
                            <?php endif; ?>


                        </ul>
                    </div>

                </div>

                <div class="user-div">
                    <span class="user-title "><i class="fa fa-bell"></i>الإشعارات
                            <?php if(auth()->user()->unreadNotifications->count()!=0): ?>
                          <b> <?php echo e(auth()->user()->unreadNotifications->count()); ?></b>
                        <?php endif; ?>
                       </span>
                    <div class="user-list notifications-div" id="dark-scroll">
                        <ul class="list-unstyled">
                            <?php if(auth()->user()->Notifications->isNotEmpty()): ?>
                            <?php $__currentLoopData = auth()->user()->Notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <li>
                                <a href="<?php echo e(isset($notification->data['actionUrl'])?$notification->data['actionUrl']:''); ?>">
                                    <div class="full-width-img main-notify-img">

                                        <img src="<?php echo e(isset($notification->data['image'])?asset('storage/'.$notification->data['image']):asset('admin/images/main/avatar.png')); ?>" class="converted-img" alt="img" />
                                    </div>
                                
                                    <span class="time"><?php echo e($notification->created_at->diffForHumans(Carbon\Carbon::now(), false)); ?></span>
                                    <p><?php echo e(isset($notification->data['message'])?$notification->data['message']:''); ?></p>
                                </a>
                            </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                        </ul>
                    </div>

                </div>

                <div class="user-div">
                            <span class="user-title color-hover"><img src="<?php echo e(asset('admin/images/main/avatar.png')); ?>" alt="img">
<?php echo e(auth()->user()->name); ?>

                                </span>
                    <div class="user-list">
                        <ul class="list-unstyled">
                           
                            <li><a href="#"><i class="fa fa-bell"></i>الإشعارات</a></li>
                            <li><a href="<?php echo e(route('products.index')); ?>"><i class="fa fa-box"></i>المنتجات</a></li>
                            <li><a href="<?php echo e(route('users.edit',auth()->id())); ?>"><i class="fa fa-user"></i>الملف الشخصي</a></li>
                            <li><a href="<?php echo e(route('Logout')); ?>"><i class="fa fa-sign-out-alt"></i>خروج</a></li>
                        </ul>
                    </div>

                </div>
            </div>
            <!--end div-->

        </div>
    </div>
</header>
<!--end header-->
<?php /**PATH /home/harajplus/public_html/resources/views/admin/layouts/header.blade.php ENDPATH**/ ?>
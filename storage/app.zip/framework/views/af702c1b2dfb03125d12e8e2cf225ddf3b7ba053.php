<!-- start footer
     ================ -->
<footer>
    <div class="col-12">
        <a href="http://www.jaadara.com" target="_blank" title="jaadara">
            مؤسسة حراج بلص التجارية ® - السعودية (2020) 

        </a>
    </div>
</footer>
<!--end footer-->
<?php /**PATH /home/harajplus/public_html/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>
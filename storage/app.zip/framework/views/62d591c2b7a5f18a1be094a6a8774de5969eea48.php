


<?php $__env->startSection('pageTitle'); ?>
    لوحة التحكم
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageSubTitle'); ?>
    اضافة مدينة
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--start row-->
    <div class="row">
        <!--start div-->
        <div class="breadcrumbes col-12">
            <ul class="list-inline">
                <li><a href="<?php echo e(route('main')); ?>"><i class="fa fa-home"></i>الرئيسية</a></li>
                <li>اضافة مدينة</li>
            </ul>
        </div>
        <!--end div-->


        <!--start div-->
        <div class="col-md-12 clients-grid margin-bottom-div">
            <div class="main-white-box">
                <h3 class="sec-title color-title"><span>إضافة مدينة</span></h3>
                <?php echo $__env->make('alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form class="needs-validation row border-form" id="myform" novalidate="" method="post"  action="<?php echo e(route('cities.store')); ?>"
                >
                    <?php echo csrf_field(); ?>



                    <div class="form-group  col-md-6">
                        <label>الإسم<span class="starrisk">*</span></label>
                        <input type="text" class="form-control" placeholder="الإسم" name="name" required>
                        <div class="invalid-feedback">
                            من فضلك أدخل اسم المدينة
                        </div>
                        <?php if($errors->has('name')): ?>
                            <div style="display:block;" class="invalid-feedback"><?php echo e($errors->first('name')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group  col-md-6">
                        <label>الدولة<span class="starrisk">*</span></label>
                        <select class="form-control" name="country_id" required>
                            <option value="" selected disabled>اسم الدولة</option>
                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                        <div class="invalid-feedback">
                            من فضلك اختر  الدولة
                        </div>
                        <?php if($errors->has('country_id')): ?>
                            <div style="display:block;" class="invalid-feedback"><?php echo e($errors->first('country_id')); ?></div>
                        <?php endif; ?>
                    </div>

                    <div class="form-group  margin-top-div text-center col-12">
                        <button type="submit" class="custom-btn">حفظ</button>
                    </div>



                </form>
            </div>

        </div>
        <!--end div-->

    </div>
    <!--end row-->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script>
        //phone
        $(function () {
            var input = document.querySelector("#phone");
            window.intlTelInput(input, {
                preferredCountries: ["sa", "eg"],
                utilsScript: "js/utils.js",
            });

        });
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/admin/cities/create.blade.php ENDPATH**/ ?>
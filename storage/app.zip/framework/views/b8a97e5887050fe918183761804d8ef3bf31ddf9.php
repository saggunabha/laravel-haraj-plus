<?php $__env->startSection('content'); ?>
    <section class="order-div main-index-order">
        <!-- start slider-products
         ================ -->
        <section class="slider-products  wow fadeIn">
            <div class="container">
                <div class="row">
                    <div class="col-12 gray-bg row no-marg-row">
                        <div class="col-xl-2 latest-title-grid">
                            <div class="new-product-box">
                                أحدث المنتجات
                            </div>
                        </div>
                          <div class="col-xl-10 no-marg-row">
                            <div id="owl-demo6" class="owl-carousel owl-theme no-full-images    products-carousel2">
                                <!--start item-->
                                <?php if(!$recentProducts->isEmpty()): ?>
                                    <?php $__currentLoopData = $recentProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="item">
                                            <!--start product-grid-->
                                            <div class="product-grid md-center">
                                                <div class="product-div">
                                                    <div class="product-img">
                                                        <a  href="<?php echo e(asset('storage/'.$product->main_image)); ?>"
                                                           class="html5lightbox"
                                                           data-group="set-1">
                                                            <img src="<?php echo e(asset('storage/'.$product->main_image)); ?>"
                                                                 alt="logo"/>
                                                        </a>
                                                       <!-- <?php if(auth()->id()): ?>-->
                                                       <!--     <?php if($favouriteProducts!=[] ): ?>-->

                                                       <!--         <span-->
                                                       <!--             <?php if(in_array($product->id,$favouriteProducts)): ?> class="fav-icon first_bg active"-->
                                                       <!--             <?php else: ?> class="fav-icon first_bg " <?php endif; ?>  ><i-->
                                                       <!--                 class="far fa-heart"></i></span>-->
                                                       <!--     <?php else: ?>-->
                                                       <!--         <span class="fav-icon first_bg">-->

                                                       <!--<i class="far fa-heart"></i>-->

                                                       <!--</span>-->
                                                       <!--     <?php endif; ?>-->
                                                       <!-- <?php endif; ?>-->
                                                    </div>
                                                    <a  href="<?php echo e(route('product-details',$product->id.'-'.$product->name)); ?>">
                                                        <div class="product-details">
                                                            <h3 class="product-name first_color"><?php echo e($product->name); ?> </h3>
                                                            <?php if($product->discount_ratio): ?>
                                                                <span class="new-price price"><?php echo e($product->price-$product->price*$product->discount_ratio/100); ?>  ر.س</span>
                                                                <span
                                                                    class="old-price price"><?php echo e($product->price); ?>ر.س</span>
                                                            <?php else: ?>
                                                                <span
                                                                    class="new-price price"><?php echo e($product->price); ?> ر.س</span>
                                                            <?php endif; ?>

                                                            <span
                                                                class="product-time second_bg first_color"><?php echo e($product->created_at->diffForHumans(Carbon\Carbon::now(), false)); ?> </span>

                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                            <!--end product-grid-->
                                        </div>
                                        <!--end item-->
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--end slider-products-->



        <!-- start-main-setions -->
        <div class="sections-div gray-bg categories-sec">
            <div class="container">
                <div class="row">
                    <?php $__currentLoopData = $subCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <a  href="<?php echo e(route('categoryProducts',$subCategory->id.'-'.$subCategory->name)); ?>">
                            <div class="img-section">
                                <img src="<?php echo e(asset('/storage/' . $subCategory->image)); ?>" alt="">
                                <div class="text-section">
                                    <h3><?php echo e($subCategory->name); ?></h3>
                                </div>
                            </div>
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                </div>
            </div>
        </div>
        <!-- end-main-setions -->
        
        
        <!-- start main-slider
         ================ -->
        <section class="main-slider  wow fadeIn">
            <div class="container-fluid">
                <div class="row">
                    <div id="owl-demo" class="owl-carousel owl-theme main-carousel top-nav">
                        <!-- start owl-item -->
                        <?php if(!$sliders->isEmpty()): ?>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="item">
                                    <div class="slider-img full-width-img">
                                        <img src="<?php echo e(asset('storage/'.$slider->image)); ?>" class="converted-img"
                                             alt="slider img"/>
                                    </div>

                                    <div class="slider-caption">
                                        <div class="container">
                                            <h2 class="first_color"><?php echo e($slider->title); ?> </h2>
                                            <p>
                                                <?php echo e($slider->body); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <!-- end owl-item -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>

                </div>
            </div>
        </section>
        <!--end main-slider-->


    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('website/js/price.js')); ?>" type="text/javascript"></script>
    <script src="<?php echo e(asset('website/js/index.js')); ?>" type="text/javascript"></script>


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/harajplus/public_html/resources/views/website/sub_category.blade.php ENDPATH**/ ?>
<div class="logo-div">
    <a rel="nofollow" id="link"  href="{{$ad->link}}" target="_blank">
        <img src="{{asset('storage/'.$ad->image)}}" alt="logo" />
    </a>
</div>
